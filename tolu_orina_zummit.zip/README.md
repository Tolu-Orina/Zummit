### **Project:** House Price Prediction with Machine Learning

### **Problem Statement**

The goal of this data science project is to use the house price dataset to construct a regression machine-learning system for forecasting the cost of homes.

### **Task**

To implement a machine learning model capable of predicting the best future house sale prices.

**The most important features seen in the data set include**;
 
- the sqft_living (demonstrates the size of the house)
- grade (demonstrates the quality of the house)
- latitude and longitude (gives insight to the location of the house)


***NOTE***: More extensive analysis would have been carried out, but because of time constraint I have built a simple but effective proof of concept for this project.
The extensive analysis excluded include:
- Exploratory Data Analysis especially on the independent variables
- Feature engineering such as one-hot encoding e.t.c

These also led to the poor performance of the neural network model on the dataset.

